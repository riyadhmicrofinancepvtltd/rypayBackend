export const KycRequiredDocTypes = [
    'PAN',
    'AADHAR_BACK_SIDE',
    'AADHAR'
]
export const ServiceTypes = {
    Wallet: 'WALLET',
    Electricity: 'ELECTRICITY',
    Mobile: 'MOBILE',
    DTH: 'DTH',
    REFERREL: 'Referel'
}
export enum PaymentMode {
    UPI = 'upi',
    NUMBER = 'number',
    BANK = 'bank',
  }
export enum FileType {
  AADHAR = 'AADHAR',
  AADHAR_BACK_SIDE = 'AADHAR_BACK_SIDE',
  PAN = 'PAN'
}
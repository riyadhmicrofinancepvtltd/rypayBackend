export enum KycVerificationStatus {
  NOT_INITIATED,
  REQUESTED,
  COMPLETED,
  REJECTED,
  VERIFIED
}

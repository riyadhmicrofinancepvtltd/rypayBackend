export enum WalletStatus {
    ACTIVE = 'active',
    INACTIVE = 'inactive',
  }
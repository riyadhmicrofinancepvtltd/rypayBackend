export enum LoanStatus {
    Pending = "Pending",
    PartiallyPending = "PartiallyPaid",
    Paid = "Paid"
}
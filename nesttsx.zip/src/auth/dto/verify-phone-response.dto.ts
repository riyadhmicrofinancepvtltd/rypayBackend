export class VerifyPhoneResponse {
  message: string;
}

export interface IRefreshTokenPayload {
  jti: string;
  sub: string;
}

export interface IAccessTokenUserPayload {
  userId: string;
  phoneNumber: string;
  role: string;
}

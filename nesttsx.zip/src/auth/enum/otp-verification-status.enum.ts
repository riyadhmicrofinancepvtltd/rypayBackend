export enum OTPValidateStatus {
  NOT_FOUND = 'Record Not Found',
  EXPIRED = 'OTP Expired',
  VALID = 'Valid OTP',
  INVALID = 'Invalid OTP',
}

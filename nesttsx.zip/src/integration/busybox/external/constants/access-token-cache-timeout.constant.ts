export const BusyBoxAccessTokenTTL = 3600 * 1000; // 1hr
export const BusyBoxAccessTokenCacheKey = 'busy-box-access-token-key';

export const PayoutDescription = 'Paid to A/C: {maskedAccount}';
export const PaymentGatewayDescription = 'Payment Received';

export const getFakeCardVerificationResponse = () => ({
    "statusCode": "S0200",
    "message": "Registration Verified Successfully",
    "data": {
      "mobileNumber": "918638707921",
      "name": "Faruque Ahmed",
      "code": "M09",
      "fullKYCCompleted": false,
      "kycCompleted": false,
      "docUploaded": true
    }
  })
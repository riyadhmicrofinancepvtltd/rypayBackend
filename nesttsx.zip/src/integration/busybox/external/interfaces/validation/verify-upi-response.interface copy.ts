
export interface IVerifyUpiResponseDTO {
  resp_code: string;
  status: string;
  txn_id: number;
  message: string;
  account_number: string;
  ifsc_code: string;
  NameInBank: string;
}

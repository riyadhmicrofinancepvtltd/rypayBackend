
export class IVerifyAccountRequestDTO {
  account_number: string;
  ifsc_code: string;
}

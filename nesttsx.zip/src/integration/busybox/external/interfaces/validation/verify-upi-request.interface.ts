
export class IVerifyUPIRequestDTO {
    upi_vpa: string
}

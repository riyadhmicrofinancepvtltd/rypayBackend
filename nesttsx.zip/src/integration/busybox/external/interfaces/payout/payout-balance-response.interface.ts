export interface PayoutBalance {
    "resp_code": string,
    "balance": string
}
export interface IUPIPayoutRequestBody {
    account_number: string,
    amount: number,
    mobile: string,
    mode: string
}
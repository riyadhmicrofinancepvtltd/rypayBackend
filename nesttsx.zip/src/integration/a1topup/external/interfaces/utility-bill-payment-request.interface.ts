export interface IUtilityBillPaymentRequest {
    number: string;
    amount: string;
    opid: string;
    order_id: string;
    mobile: string;
    reference_id: string;
}
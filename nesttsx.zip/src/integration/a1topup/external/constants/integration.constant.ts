export const RedisKeyConstant = {
    PlanApiTTL: 24 * 60 * 60 * 1000
}
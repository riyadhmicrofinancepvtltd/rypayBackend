export enum TransactionType {
    CREDIT = 'CREDIT',
    DEBIT = 'DEBIT',
}
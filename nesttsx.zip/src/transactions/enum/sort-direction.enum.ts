export enum SORT_DIRECTIONS{
    ASC = "ASC",
    DESC = "DESC"
}
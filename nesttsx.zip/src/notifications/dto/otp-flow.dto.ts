export class OTPFLowDto {
  route: string;
  sender_id: string;
  message: string;
  variables_values: string;
  flash: number;
  numbers: string;
}

export const newUserNotification = (userName: string) => `Hi ${userName}, Welcome to RYPAY! Get ready to explore Awsome features 
and enjoy secure payments`;
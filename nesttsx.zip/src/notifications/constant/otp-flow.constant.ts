export const OTPFlowPayload = {
  route: 'dlt',
  sender_id: 'RYMFNC',
  message: '171356',
  flash: 0,
};
